library(TwoSampleMR)
library(MRPRESSO)
library(tidyverse)
library(data.table)
library(ggplot2)
library(openxlsx)
library(MendelianRandomization)
library(ieugwasr)
library(plinkbinr)

#####暴露总数据
gut_all<-fread("F:\\MR-LY\\Data\\Data_MBG.allHits.IVs_p.1e-5.txt",data.table = F, header = T)
#####结局总数据
whr<-fread("F:\\MR-LY\\Data\\whr.giant-ukbb.meta_zhengli.txt",data.table = F,header=T)
whr$phenotype <- 'whr'

#####每次跑单个菌种
bac.list<-read.xlsx("F:\\MR-LY\\Data\\GutList_0428.xlsx",sheet = "AllBac",colNames = FALSE)##
for(i in 1:dim(bac.list)[1]){#####循环起止，注意核对dim(bac.list)[1]

###单个菌种
bacname<-bac.list[i,]################################bacname为变量
gut_sin<-gut_all[which(gut_all$bac==bacname),]
###暴露数据;4个必须列：SNP,beta,se,effect_allele。其他可能有助于MR预处理或分析的列：other_allele,eaf,Phenotype。
exp_dat<-format_data(dat=gut_sin,type='exposure',
phenotype_col = "bac",
snp_col = "rsID",
beta_col = "beta",
se_col = "SE",
effect_allele_col ="eff.allele",
other_allele_col = "ref.allele",
pval_col = "P.weightedSumZ",
samplesize_col="N",
chr_col="chr")
dim(exp_dat)
###结局变量
out_dat <- format_data(dat=whr,type = "outcome",
snps = exp_dat$SNP,
phenotype_col = "phenotype",
snp_col = "SNP",
beta_col = "BETA",
se_col = "SE",
effect_allele_col = "Tested_Allele",
other_allele_col = "Other_Allele",
pval_col = "P",
chr_col = "CHR",
pos_col = "POS",
eaf_col="Freq_Tested_Allele",
samplesize_col="N")##结局因素，必须提供样本数，否则计算steiger时会报错
dim(out_dat)
###########harmonise
mydata <- harmonise_data(exposure_dat=exp_dat,outcome_dat=out_dat,action=2)
mydata <- mydata[which(mydata$mr_keep==TRUE),]
dim(mydata)
##########clump步骤
exp_dat_harm<-filter(exp_dat,exp_dat$SNP %in% mydata$SNP)
dim(exp_dat_harm)
####################################本地clump
exp_dat_clump<-ld_clump(
  clump_kb=500,
  clump_r2=0.01,
  pop="EUR",
  dplyr::tibble(rsid=exp_dat_harm$SNP, pval=exp_dat_harm$pval.exposure, id=exp_dat_harm$id.exposure),
  plink_bin = "D:/R-4.3.1/library/plinkbinr/bin/plink_Windows.exe",#get_plink_exe()
  bfile = "F:/MR-LY/Data/EUR_ref/1kg.v3/EUR"#欧洲人群参考基因组位置
)
dim(exp_dat_clump)
mydata_clump<-subset(mydata, SNP %in% exp_dat_clump$rsid)
####################################

###与结局相关的snp去掉!!!!!!!!!!!!!!!!
mydata_filteroutcome<-mydata_clump[which(mydata_clump$pval.outcome>=0.05),]
###MAF>0.01
mydata_filteroutcome<-mydata_filteroutcome[which(mydata_filteroutcome$eaf.outcome>0.01),]



##########MR-PRESSO,去除outliers。当p<0.05，对单个snp的p值从小到大排序，逐个剔除，直到剩下的IVs的p>=0.05
####mydata_clun IV工具变量个数<=3，无法进行mr-presso
mydata_outcomen<-dim(mydata_filteroutcome)[1]
if(mydata_outcomen<=3){
	presso_pval<-"NA"
	mydata_presso<-mydata_filteroutcome
	}else{
		presso <- mr_presso(BetaOutcome = "beta.outcome", BetaExposure = "beta.exposure", 
		SdOutcome = "se.outcome", SdExposure = "se.exposure", 
		OUTLIERtest = TRUE, DISTORTIONtest = TRUE, 
		data = mydata_filteroutcome, 
		NbDistribution = 1000,  SignifThreshold = 0.05)
		presso
		presso_pval<-presso$`MR-PRESSO results`$`Global Test`$Pvalue
		presso_snp<-presso$`MR-PRESSO results`$`Outlier Test`
		###mydata_presso pvalue
		###presso_pval>0.05，不需去除outliers
		if(presso_pval>=0.05){
			#mydata_presso
			mydata_presso<-mydata_filteroutcome
		}else{
		###presso_pval<0.05，说明存在多效性，需要去除outliers
			#去除outliers
############################
out_order<-order(presso_snp$Pvalue)
out_order
for(ii in 1:length(out_order)){
	snp_ii<-out_order[1:ii]
	mydata_presso<-mydata_filteroutcome[-snp_ii,]
	mydata_presn<-dim(mydata_presso)[1]
	if(mydata_presn<=3){
		presso_pval<-"NA"
		}else{
		presso2 <- mr_presso(BetaOutcome = "beta.outcome", BetaExposure = "beta.exposure", 
		SdOutcome = "se.outcome", SdExposure = "se.exposure", 
		OUTLIERtest = TRUE, DISTORTIONtest = TRUE, 
		data = mydata_presso, 
		NbDistribution = 1000,  SignifThreshold = 0.05)
		presso_pval<-presso2$`MR-PRESSO results`$`Global Test`$Pvalue
		#mydata_presso
		mydata_presso<-mydata_presso
		}
	print(ii);
	if(presso_pval>=0.05){
		break;##终止for循环
	}
}
############################
		}
}
dim(mydata_presso)


#filter
expn<-dim(exp_dat)[1]
outn<-dim(out_dat)[1]
mydata_harn<-dim(mydata)[1]
mydata_clun<-dim(mydata_clump)[1]
mydata_outcomen<-dim(mydata_filteroutcome)[1]
mydata_presn<-dim(mydata_presso)[1]

filter_data<-data.frame(expn,outn,mydata_harn,mydata_clun,mydata_outcomen,mydata_presn,presso_pval)
filter_data


########MR Steiger directionality test##steiger也是一种敏感性分析
steiger_snpi<-steiger_filtering(mydata_presso) ##文献是根据steiger_dir=FALSE来剔除的
out <- directionality_test(mydata_presso)
#计算F统计量
k<-mydata_presn
N<-18340
r2.exposure<-out$snp_r2.exposure
F.exposure<-(r2.exposure/(1-r2.exposure))*((N-k-1)/k)
out$F.exposure<-F.exposure




##########MR分析
set.seed(123456)
res<-mr(mydata_presso, method_list=c("mr_egger_regression", "mr_ivw","mr_ivw_mre","mr_ivw_fe","mr_wald_ratio","mr_weighted_median","mr_two_sample_ml","mr_simple_mode","mr_weighted_mode"))#常见8种方法
res2<-mr(mydata_presso, method_list=c("mr_egger_regression", "mr_ivw","mr_weighted_median","mr_two_sample_ml","mr_weighted_mode"))####出散点图用
res_or<-generate_odds_ratios(res)
##########异质性、多效性、敏感性
het<-mr_heterogeneity(mydata_presso, method_list=c("mr_egger_regression", "mr_ivw"))#the mr_heterogeneity() function can take an argument to only perform heterogeneity tests using specified methods
plt<-mr_pleiotropy_test(mydata_presso)
res_loo<-mr_leaveoneout(mydata_presso)
##########可视化
####散点图
p1<-mr_scatter_plot(res,mydata_presso)
p1.2<-mr_scatter_plot(res2,mydata_presso)
####森林图
res_single<-mr_singlesnp(mydata_presso)
p2<-mr_forest_plot(res_single)
####漏斗图
p3<-mr_funnel_plot(res_single)
####敏感性图
p4<-mr_leaveoneout_plot(res_loo)


###########phenoscannr结果
res_phenoscanner<-phenoscanner(mydata_presso$SNP)
res_phenoscanner<-res_phenoscanner$results


###############输出数据
setwd("F:\\MR-LY\\23.09.21Result_MR_X-Y\\WHR_Result")
dir.create(bacname)#创建文件夹
filepath<-paste("F:\\MR-LY\\23.09.21Result_MR_X-Y\\WHR_Result\\",bacname,sep="")
filepath
setwd(filepath)
ggsave(p1[[1]], file="mr_scatter_plot.pdf")
ggsave(p1.2[[1]], file="mr_scatter_plot2.pdf")
ggsave(p2[[1]], file="mr_forest_plot.pdf")
ggsave(p3[[1]], file="mr_funnel_plot.pdf")
ggsave(p4[[1]], file="mr_leaveoneout_plot.pdf")
write.table(mydata_presso,"mydata_presso.txt",sep="\t",quote = FALSE,row.names = FALSE)#IVs
write.table(res,"res.txt",sep="\t",quote = FALSE,row.names = FALSE)#res
write.table(res_or,"res_or.txt",sep="\t",quote = FALSE,row.names = FALSE)#res_or
write.table(het,"het.txt",sep="\t",quote = FALSE,row.names = FALSE)#heterogeneity
write.table(plt,"plt.txt",sep="\t",quote = FALSE,row.names = FALSE)#pleiotropy
write.table(filter_data,"filter_data.txt",sep="\t",quote = FALSE,row.names = FALSE)#data filter process
write.table(steiger_snpi,"steiger_snpi.txt",sep="\t",quote = FALSE,row.names = FALSE)#steiger_filtering
write.table(out,"out.txt",sep="\t",quote = FALSE,row.names = FALSE)#steiger_pval
write.table(res_phenoscanner,"res_phenoscanner.txt",sep="\t",quote = FALSE,row.names = FALSE)#res_phenoscanner


}


