library(TwoSampleMR)
library(MRPRESSO)
library(tidyverse)
library(data.table)
library(ggplot2)
library(openxlsx)
library(MendelianRandomization)
library(ieugwasr)
library(plinkbinr)
#remotes::install_github("mrcieu/ieugwasr",force = TRUE)

#####暴露总数据          肥胖特征
obesity_feature <- list.files("H:/多变量结局数据/")
obesity_feature <- obesity_feature[-grep("R$", obesity_feature)]  ###这一步的正则表达式需要注意


##结局阳性结果数据
gut_feature <- list.files("F:/MR-LY/select result/Summary_result/gut microbe - obesity/sensitive_causal")
gut_feature <- gut_feature[-grep("R$", gut_feature)]  ###这一步的正则表达式需要注意




for (z in 5:length(obesity_feature)) {
  
  obesity_da <- fread(paste0("H:/多变量结局数据/", obesity_feature[z]))
  colnames(obesity_da)
  colnames(obesity_da) <- c("chr.exposure", "pos.exposure", "SNP", "effect_allele.exposure","other_allele.exposure",
                             "eaf.exposure", "beta.exposure","se.exposure", "pval.exposure",
                            "samplesize.exposure","INFO")
  
  obesity_da <- obesity_da[which(as.numeric(obesity_da$pval.exposure) < 5e-8),]
  
  obesity_da$phenotype <- obesity_feature[z]
  
  exp_dat<-format_data(dat = obesity_da,
                       type='exposure',
                       chr_col = "chr.exposure",
                       phenotype_col = "phenotype",
                       snp_col = "SNP",
                       beta_col = "beta.exposure",
                       se_col = "se.exposure",
                       effect_allele_col ="effect_allele.exposure",
                       other_allele_col = "other_allele.exposure",
                       pval_col = "pval.exposure",
                       samplesize_col="samplesize.exposure",
                       eaf_col = "eaf.exposure")
  
  exp_dat_clump<-ld_clump(
    clump_kb=10000,
    clump_r2=0.001,
    
    pop="EUR",
    dplyr::tibble(rsid=exp_dat$SNP, pval=exp_dat$pval.exposure, id=exp_dat$id.exposure),
    plink_bin = "D:/R-4.3.1/library/plinkbinr/bin/plink_Windows.exe", #get_plink_exe()
    bfile = "F:/MR-LY/Data/EUR_ref/1kg.v3/EUR"#欧洲人群参考基因组位置
  )
  
  
  ##########————————————————————————————————————————结局的菌
  gut_list <- fread(paste0("F:/MR-LY/select result/Summary_result/gut microbe - obesity/sensitive_causal/", gut_feature[z])) 
  gut_name <- gut_list$exposure
  ##创建主文件夹
  dir.create(paste0("F:/MR-LY/2023.10.15Results_Y-X/", obesity_feature[z]))
  
  ###############____________________________________寻找结局
  
  for (m in 1:length(gut_name)) {
    
    
    gut_da <- fread(paste0("I:/mibiogen/mibiogen_summary_all/", gut_name[m], ".summary.txt"))
    
    out_dat <- format_data(dat= gut_da,
                           type = "outcome",
                           snps = exp_dat_clump$rsid,
                           phenotype_col = "bac",
                           snp_col = "rsID",
                           beta_col = "beta",
                           se_col = "SE",
                           effect_allele_col = "eff.allele",
                           other_allele_col = "ref.allele",
                           pval_col = "P.weightedSumZ",
                           chr_col = "chr",
                           pos_col = "bp",
                           samplesize_col="N")
    
    exp_data_clump <-subset(exp_dat, SNP %in% exp_dat_clump$rsid)
    mydata <- harmonise_data(exposure_dat=exp_data_clump,outcome_dat=out_dat,action=2)
    mydata <- mydata[which(mydata$mr_keep==TRUE),]
    mydata_clump <- mydata
    
    ##创建菌的文件夹
    dir.create(paste0("F:/MR-LY/2023.10.15Results_Y-X/", obesity_feature[z], "/", gut_name[m]))
    
    ###与结局相关的snp去掉!!!!!!!!!!!!!!!!
    mydata_filteroutcome<-mydata_clump[which(mydata_clump$pval.outcome>=0.05),]
    ###MAF>0.01
    mydata_filteroutcome$MAF <- ifelse(mydata_filteroutcome$eaf.exposure <= 0.5, mydata_filteroutcome$eaf.exposure, 1-mydata_filteroutcome$eaf.outcome )
    mydata_filteroutcome <- mydata_filteroutcome[which(mydata_filteroutcome$MAF > 0.01),]
    
    #####################
    ##########MR-PRESSO,去除outliers。当p<0.05，对单个snp的p值从小到大排序，逐个剔除，直到剩下的IVs的p>=0.05
    ####mydata_clun IV工具变量个数<=3，无法进行mr-presso
    mydata_outcome_n<-dim(mydata_filteroutcome)[1]
    
    Nbd <- 1000   #nrow(mydata_filteroutcome)/0.05+1
    if(mydata_outcome_n<=3){
      presso_pval<-"NA"
      mydata_presso<-mydata_filteroutcome
    }else{
      presso <- mr_presso(BetaOutcome = "beta.outcome", BetaExposure = "beta.exposure", 
                          SdOutcome = "se.outcome", SdExposure = "se.exposure", 
                          OUTLIERtest = TRUE, DISTORTIONtest = TRUE, 
                          data = mydata_filteroutcome, 
                          NbDistribution = Nbd,  SignifThreshold = 0.05)
      presso
      presso_pval<-presso$`MR-PRESSO results`$`Global Test`$Pvalue
      presso_snp<-presso$`MR-PRESSO results`$`Outlier Test`
      ###mydata_presso pvalue
      ###presso_pval>0.05，不需去除outliers
      if(presso_pval>=0.05){
        #mydata_presso
        mydata_presso<-mydata_filteroutcome
      }else{
        ###presso_pval<0.05，说明存在多效性，需要去除outliers
        #去除outliers
        ############################
        out_order<-order(presso_snp$Pvalue)
        out_order
        for(ii in 1:length(out_order)){
          snp_ii<-out_order[1:ii]
          mydata_presso<-mydata_filteroutcome[-snp_ii,]
          mydata_pres_n<-dim(mydata_presso)[1]
          if(mydata_pres_n<=3){
            presso_pval<-"NA"
          }else{
            presso2 <- mr_presso(BetaOutcome = "beta.outcome", BetaExposure = "beta.exposure", 
                                 SdOutcome = "se.outcome", SdExposure = "se.exposure", 
                                 OUTLIERtest = TRUE, DISTORTIONtest = TRUE, 
                                 data = mydata_presso, 
                                 NbDistribution = Nbd,  SignifThreshold = 0.05)
            presso_pval<-presso2$`MR-PRESSO results`$`Global Test`$Pvalue
            #mydata_presso
            mydata_presso<-mydata_presso
          }
          print(ii);
          if(presso_pval>=0.05){
            break;##终止for循环
          }
        }
        ############################
      }
    }
    dim(mydata_presso)
    
    
    #filter
    exp_n<-dim(exp_dat)[1]
    out_n<-dim(out_dat)[1]
    mydata_har_n<-dim(mydata)[1]
    mydata_clu_n<-dim(mydata_clump)[1]
    mydata_outcome_n<-dim(mydata_filteroutcome)[1]
    mydata_pres_n<-dim(mydata_presso)[1]
    
    filter_data<-data.frame(exp_n,out_n,mydata_clu_n,mydata_har_n,mydata_outcome_n,mydata_pres_n,presso_pval)
    filter_data
    
    
    ########MR Steiger directionality test##steiger也是一种敏感性分析
    steiger_snpi<-steiger_filtering(mydata_presso) ##文献是根据steiger_dir=FALSE来剔除的
    out <- directionality_test(mydata_presso)
    
    k<-mydata_pres_n
    N<- as.numeric(names(which.max(table(obesity_da$samplesize.exposure))))#第二种方法  as.numeric(names(which.max(table(metabolites_sin$Total_N)))) 这里取最大的为准，用table统计选出最大的，在提取数值  ###这里取最大的为准，用table统计选出最大的，在提取数值
    r2.exposure<-out$snp_r2.exposure
    F.exposure<-(r2.exposure/(1-r2.exposure))*((N-k-1)/k)
    out$F.exposure<-F.exposure
    
    set.seed(5201314)
    res<-mr(mydata_presso, method_list=c("mr_egger_regression", "mr_ivw","mr_ivw_mre","mr_ivw_fe","mr_wald_ratio","mr_weighted_median","mr_two_sample_ml","mr_simple_mode","mr_weighted_mode"))#常见8种方法
    res2<-mr(mydata_presso, method_list=c("mr_egger_regression", "mr_ivw","mr_weighted_median","mr_two_sample_ml","mr_weighted_mode"))####出散点图用
    res_or<-generate_odds_ratios(res)
    ##########异质性、多效性、敏感性
    het<-mr_heterogeneity(mydata_presso, method_list=c("mr_egger_regression", "mr_ivw"))#the mr_heterogeneity() function can take an argument to only perform heterogeneity tests using specified methods
    plt<-mr_pleiotropy_test(mydata_presso)
    res_loo<-mr_leaveoneout(mydata_presso)
    ##########可视化
    ####散点图
    p1<-mr_scatter_plot(res,mydata_presso)
    p1.2<-mr_scatter_plot(res2,mydata_presso)
    ####森林图
    res_single<-mr_singlesnp(mydata_presso)
    p2<-mr_forest_plot(res_single)
    ####漏斗图
    p3<-mr_funnel_plot(res_single)
    ####敏感性图
    p4<-mr_leaveoneout_plot(res_loo)
    
    
    ###########phenoscannr结果
    #res_phenoscanner<-phenoscanner(mydata_presso$SNP)
    #res_phenoscanner<-res_phenoscanner$results
    
    
    ###############输出数据
    dir.create(paste0("F:/MR-LY/2023.10.15Results_Y-X/", obesity_feature[z], "/", gut_name[m]))#创建文件夹
    filepath <- paste0("F:/MR-LY/2023.10.15Results_Y-X/", obesity_feature[z], "/", gut_name[m], "/")
    filepath
    setwd(filepath)
    ggsave(p1[[1]], file="mr_scatter_plot.pdf")
    ggsave(p1.2[[1]], file="mr_scatter_plot2.pdf")
    ggsave(p2[[1]], file="mr_forest_plot.pdf")
    ggsave(p3[[1]], file="mr_funnel_plot.pdf")
    ggsave(p4[[1]], file="mr_leaveoneout_plot.pdf")
    write.table(mydata_presso,"mydata_presso.txt",sep="\t",quote = FALSE,row.names = FALSE)#IVs
    write.table(res,"res.txt",sep="\t",quote = FALSE,row.names = FALSE)#res
    write.table(res_or,"res_or.txt",sep="\t",quote = FALSE,row.names = FALSE)#res_or
    write.table(het,"het.txt",sep="\t",quote = FALSE,row.names = FALSE)#heterogeneity
    write.table(plt,"plt.txt",sep="\t",quote = FALSE,row.names = FALSE)#pleiotropy
    write.table(filter_data,"filter_data.txt",sep="\t",quote = FALSE,row.names = FALSE)#data filter process
    write.table(steiger_snpi,"steiger_snpi.txt",sep="\t",quote = FALSE,row.names = FALSE)#steiger_filtering
    write.table(out,"out.txt",sep="\t",quote = FALSE,row.names = FALSE)#steiger_pval
    
  }
  print(z)
}






 
  
  




